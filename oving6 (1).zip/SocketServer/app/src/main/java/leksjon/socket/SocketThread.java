package leksjon.socket;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class SocketThread extends Thread{

    public Socket s;
    PrintWriter out 	= null;
    BufferedReader in 	= null;
    private final static String TAG = "ServerThread";


    public SocketThread(Socket s){
        this.s=s;
    }

    public void run(){
        try {

            out = new PrintWriter(s.getOutputStream(), true);
            in = new BufferedReader(
                    new InputStreamReader(s.getInputStream()));

            String str1 = in.readLine();
            Log.v(TAG, "client sent first: " + str1);

            String str2 = in.readLine();
            Log.v(TAG, "client sent then: " + str2);

            int res = Integer.parseInt(str1) + Integer.parseInt(str2);
            out.println(res);//send text to client
            Log.v(TAG, "responded with: " + res);
        }catch (Exception e){}finally {
            try {

                out.close();
                in.close();
                s.close();
            }catch (Exception e){}
        }
    }




}
