package leksjon.socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Enumeration;

import android.util.Log;

public class Server extends Thread{
	private final static String TAG = "ServerThread";
	private final static int PORT = 12345;
	
	public void run() {

		ServerSocket ss 	= null;

		try{
    		Log.i(TAG,"start server....");
            ss = new ServerSocket(PORT);
			InetAddress ia = ss.getInetAddress();
			Log.i(TAG,"serversocket created, wait for client....");
			while (true) {
				Socket s = ss.accept();
				Log.v(TAG, "client connected...");
				new SocketThread(s).run();
			}



        } catch (IOException e) {
            e.printStackTrace();
        }finally{//close sockets!!
        	try{

        		ss.close();
        	}catch(Exception e){}	            	
        }   
	}


}
