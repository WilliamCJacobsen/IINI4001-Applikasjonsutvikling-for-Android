package leksjon.socket;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ClientActivity extends Activity {
    /**
     * Called when the activity is first created.
     */
    EditText num1;
    EditText num2;
    Button b;
    Client c;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        b = findViewById(R.id.send);
        num1 = findViewById(R.id.tall1);
        num2 = findViewById(R.id.tall2);
        b.setOnClickListener(e -> sendNums());
    }

    public void sendNums() {
        c=new Client(this);
        String numb1 = num1.getText().toString();
        String numb2 = num2.getText().toString();
        c.num1=numb1;
        c.num2=numb2;
        c.start();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Toast.makeText(this, c.res,Toast.LENGTH_LONG).show();
    }
}