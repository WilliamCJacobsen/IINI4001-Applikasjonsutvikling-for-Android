package leksjon.socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketException;
import java.util.Enumeration;

import android.util.Log;
import android.widget.Toast;

public class Client extends Thread {
    private final static String TAG = "MyClient";
    private final static String IP = "10.0.2.2";
    private final static int PORT = 12345;
    public String num1="1";
    public String num2="2";
    public String res="e";
    public ClientActivity ca;

    public Client(ClientActivity ca){
        this.ca=ca;
    }


    public void run() {
        Socket s = null;
        PrintWriter out = null;
        BufferedReader in = null;

        try (final DatagramSocket socket = new DatagramSocket()) {
            socket.connect(InetAddress.getByName("10.0.2.2"), 12345);
        } catch (Exception e) {
        }

        try {
            Log.i(TAG, "C: befor socket");
            if(s==null) {
                s = new Socket(IP, PORT);
                Log.i(TAG, "C: Connected to server" + s.toString());
                out = new PrintWriter(s.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            }
            out.println(num1);
            out.println(num2);

            String result = in.readLine();
            Log.i(TAG,"got back: "+result);
            res=result;
        } catch (IOException e) {
            Log.i(TAG, "run: " + e.toString());
        } finally {//close socket!!
            try {
                out.close();
                in.close();
                s.close();
            } catch (IOException e) {
            }
        }

    }

//    public String sendNums(String num1, String num2) {
//
////        out.println(num1);
////        out.println(num2);
////        this.num1 = num1;
////        this.num2 = num2;
////        run();
////        try {
////            return in.readLine();
////        } catch (IOException e) {
////            e.printStackTrace();
////        }
//        return "error";
//    }

}