package com.example.william.ovning5;

public class Requests {

    public static String REGISTER_DATA = "REGISTER_DATA";
    public static String USER_NAME = "USER_NAME";
}
